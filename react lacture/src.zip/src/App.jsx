import React from 'react'
import Card from './components/Card'
import Welocome from './components/Welocome'

const App = () => {
  return (
    <>
      <Card/>
      <Card/>
      <Welocome/>
    </>
  )
}

export default App