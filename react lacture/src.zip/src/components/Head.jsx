import React from 'react'

const Head = () => {
  return (
     <h1>Header</h1>
  )
}

export default Head