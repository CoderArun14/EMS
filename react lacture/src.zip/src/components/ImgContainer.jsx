import React from 'react'

const ImgContainer = () => {
  return (
    <div className="img"><img src="1.jpg" alt="" /></div>
  )
}

export default ImgContainer