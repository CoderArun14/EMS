import React from 'react'

const Welocome = () => {
  return (
    <>
        <div className="wel">
        <h1>Welcome</h1>
        <p>Dosto</p>
        </div>
    </>
  )
}

export default Welocome