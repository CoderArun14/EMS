import { createContext } from "react";

export const storeProvide = createContext([])