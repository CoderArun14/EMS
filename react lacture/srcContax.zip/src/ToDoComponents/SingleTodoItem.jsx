import React from 'react'

const SingleTodoItem = () => {
  return (
    <div>SingleTodoItem</div>
  )
}

export default SingleTodoItem