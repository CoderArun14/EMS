import React from 'react'
import ToDoContainers from './ToDoComponents/ToDoContainers'
import AppName from './ToDoComponents/AppName'

const App = () => {
  return (
    <>
    
    <ToDoContainers/>
    </>
  )
}

export default App