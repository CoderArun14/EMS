import React from 'react'

const Head = (props) => {
  return (
     <h1>{props.title}</h1>
  )
}

export default Head