import React from 'react'

const ImgContainer = (props) => {
  return (
    <div className="img"><img src={props.imgAdd} alt="" /></div>
  )
}

export default ImgContainer