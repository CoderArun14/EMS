import React, { useState } from 'react'
import AppName from './AppName'
import AddTodoItems from './AddTodoItems'
import TodoItemSContainer from './TodoItemSContainer'

const ToDoContainers = () => {
    let data = [
        {
            work:"agra jana hai",
            myDate:"18/11/2024"
        },
        {
            work:"agra jana hai",
            myDate:"18/11/2024"
        },
        {
            work:"agra jana hai",
            myDate:"18/11/2024"
        }
    ]
    let [addTodo,setaddTodo] = useState(data)
   
    const handleAdd = (work,myDate)=>{
        let newData = {
            work,
            myDate
        }
        setaddTodo([...addTodo,newData])
        
    }
    const handleDelete = (id)=>{
        let afterDel = addTodo.filter((elm,ind)=> ind !=id)
        setaddTodo(afterDel)
    }
  return (
    <div className="container " >
        <div className="row">
            <div className="col-8  mx-auto">
                <AppName/>
                <AddTodoItems handleAdd={handleAdd}/>
                {addTodo.length==0 && <h1>There is no Task</h1>}
                <TodoItemSContainer handleDelete={handleDelete} data={addTodo}/>
            </div>
        </div>
    
    </div>
  )
}

export default ToDoContainers