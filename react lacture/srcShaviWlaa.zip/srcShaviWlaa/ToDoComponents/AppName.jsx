import React from 'react'

const AppName = () => {
  return (
    <h1 className='text-center'>ToDo</h1>
  )
}

export default AppName