import React from 'react'

const First = ({imgAdd}) => {
  return (
    <><div>
    <img src={imgAdd} alt="" className='img-fluid' />

    </div>
    </>
  )
}

export default First