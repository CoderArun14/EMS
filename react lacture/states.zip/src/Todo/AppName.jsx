import React from 'react'

const AppName = () => {
  return (
    <h1>AppName</h1>
  )
}

export default AppName