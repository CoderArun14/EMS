import React from 'react'
import CardContainer from './Components/CardContainer'

const App = () => {
  return (
    <>
  <CardContainer/>
    </>
  )
}

export default App