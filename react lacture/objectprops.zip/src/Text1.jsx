import React from 'react'

const Text1 = () => {
  return (
    <div>Text1</div>
  )
}

export default Text1