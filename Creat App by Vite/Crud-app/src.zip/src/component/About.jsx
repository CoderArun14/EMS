import React from 'react'

const About = () => {
  return (
    <div>Create by Coder Ap</div>
  )
}

export default About