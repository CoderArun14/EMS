// import React from 'react'


const Sectwo = () => {
  return (
    <>
    <div className="Sectwo">
    <ul>
      <li>India</li>
      <li>Pakistan</li>
      <li>China</li>
      <li>Australia</li>
    </ul>
    <img src="https://imgv3.fotor.com/images/gallery/cartoon-character-generated-by-Fotor-ai-art-creator.jpg" alt="" />
    </div>
    </>
  )
}

export default Sectwo