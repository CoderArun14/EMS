// import React from 'react'

export const Secthree = () => {
  return (
    <>
     <div className="Secthree">
        <div className="color"></div>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod quos sequi rerum nihil omnis eligendi at distinctio velit voluptatum suscipit hic eos nisi saepe quia, iusto facere facilis et! Aliquid.</p>
      </div>
    </>
  )
}
export default Secthree
