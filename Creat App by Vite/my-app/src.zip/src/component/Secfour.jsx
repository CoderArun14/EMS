// import React from 'react'

const Secfour = () => {
  return (
    <>
    <div className="Secfour">
        <img src="https://photutorial.com/wp-content/uploads/2023/04/Featured-image-AI-image-generators-by-Midjourney.png" alt="" />
      <div className="Second"></div>
      </div>
    </>
  )
}

export default Secfour